#!/bin/bash

TOTAL_RUN=10

echo "alloc_rp.sh starting......"

CDIR=$(pwd)

cd ~/apps/apps/RSBench/refactored/ocr/intel-sharedDB/
rm -r install_*
./allocProfileRTScript.sh $TOTAL_RUN
./jobScriptRtProfile.sh

cd ~/apps/apps/hpcg/refactored/ocr/intel-Eager/
rm -r install_*
./allocProfileRTScript.sh $TOTAL_RUN
./jobScriptRtProfile.sh

cd ~/apps/apps/CoMD/refactored/ocr/intel-chandra-tiled/
rm -r install_*
./allocProfileRTScript.sh $TOTAL_RUN
./jobScriptRtProfile.sh

cd $CDIR

echo "alloc_rp.sh completed"
