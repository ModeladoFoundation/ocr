#!/bin/bash

echo '===============================================' 
echo ' Run-time test: 1                          ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_runtime_1 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_runtime_1 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_runtime_1.out
echo '===============================================' 
echo ' Run-time test: 2                          ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_runtime_2 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_runtime_2 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_runtime_2.out
echo '===============================================' 
echo ' Run-time test: 3                          ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_runtime_3 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_runtime_3 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_runtime_3.out
echo '===============================================' 
echo ' Run-time test: 4                          ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_runtime_4 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_runtime_4 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_runtime_4.out
echo '===============================================' 
echo ' Run-time test: 5                          ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_runtime_5 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_runtime_5 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_runtime_5.out
echo '===============================================' 
echo ' Run-time test: 6                          ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_runtime_6 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_runtime_6 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_runtime_6.out
echo '===============================================' 
echo ' Run-time test: 7                          ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_runtime_7 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_runtime_7 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_runtime_7.out
echo '===============================================' 
echo ' Run-time test: 8                          ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_runtime_8 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_runtime_8 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_runtime_8.out
echo '===============================================' 
echo ' Run-time test: 9                          ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_runtime_9 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_runtime_9 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_runtime_9.out
echo '===============================================' 
echo ' Run-time test: 10                          ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_runtime_10 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_runtime_10 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_runtime_10.out
echo '===============================================' 
echo ' Enable profiling                              ' 
echo '===============================================' 
sed -i '/CFLAGS += -DOCR_RUNTIME_PROFILER -DPROFILER_KHZ=3400000/c\CFLAGS += -DOCR_RUNTIME_PROFILER -DPROFILER_KHZ=3400000' ~/ocr/ocr/build/common.mk
echo '===============================================' 
echo ' Running profile: 1	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_profile_1 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_profile_1 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_profile_1.out
echo '===============================================' 
echo ' Running profile: 2	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_profile_2 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_profile_2 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_profile_2.out
echo '===============================================' 
echo ' Running profile: 3	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_profile_3 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_profile_3 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_profile_3.out
echo '===============================================' 
echo ' Running profile: 4	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_profile_4 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_profile_4 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_profile_4.out
echo '===============================================' 
echo ' Running profile: 5	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_profile_5 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_profile_5 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_profile_5.out
echo '===============================================' 
echo ' Running profile: 6	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_profile_6 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_profile_6 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_profile_6.out
echo '===============================================' 
echo ' Running profile: 7	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_profile_7 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_profile_7 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_profile_7.out
echo '===============================================' 
echo ' Running profile: 8	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_profile_8 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_profile_8 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_profile_8.out
echo '===============================================' 
echo ' Running profile: 9	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_profile_9 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_profile_9 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_profile_9.out
echo '===============================================' 
echo ' Running profile: 10	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_profile_10 make -f Makefile.x86-phi clean uninstall
CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./install_profile_10 WORKLOAD_ARGS='4 4 4 64 30 0' make -f Makefile.x86-phi run &> install_profile_10.out
echo '===============================================' 
echo ' Disable profiling                             ' 
echo '===============================================' 
sed -i '/CFLAGS += -DOCR_RUNTIME_PROFILER -DPROFILER_KHZ=3400000/c\# CFLAGS += -DOCR_RUNTIME_PROFILER -DPROFILER_KHZ=3400000' ~/ocr/ocr/build/common.mk
echo '===============================================' 
echo ' job completed.                                '
echo '===============================================' 
