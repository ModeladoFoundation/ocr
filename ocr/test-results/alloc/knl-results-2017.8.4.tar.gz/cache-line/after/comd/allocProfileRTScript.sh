#!/bin/bash

#source $APPS_ROOT/tools/execution_tools/aux_bash_functions

#########################################################################################
if [[ "$1" != "" ]]; then
    TOTAL_RUN="$1"
else
    TOTAL_RUN=1
fi
echo "TOTAL_RUN = ${TOTAL_RUN}"

IS_RSBENCH=0
RUNTIME_CFG=1
PROFILE_CFG=1
TARGET='x86-phi'

# workload for RSBench 
#IS_RSBENCH=1
#WORKLOAD=' -d -s large -t 64 -l 8000000'

# workload for HPCG
#WORKLOAD='4 4 4 64 30 0'

# workload for CoMD
WORKLOAD="-x 192 -y 192 -z 192 -i 4 -j 4 -k 4 -N 100 -n 100"


function enableProfile()
{
    local x=$1

    if [ $x -eq 0 ]; then
        echo "echo '===============================================' " >> ${jfile}.sh
        echo "echo ' Disable profiling                             ' " >> ${jfile}.sh
        echo "echo '===============================================' " >> ${jfile}.sh
	MOD_CMD="sed -i '/CFLAGS += -DOCR_RUNTIME_PROFILER -DPROFILER_KHZ=3400000/c\# CFLAGS += -DOCR_RUNTIME_PROFILER -DPROFILER_KHZ=3400000' ~/ocr/ocr/build/common.mk"
    else
        echo "echo '===============================================' " >> ${jfile}.sh
        echo "echo ' Enable profiling                              ' " >> ${jfile}.sh
        echo "echo '===============================================' " >> ${jfile}.sh
        MOD_CMD="sed -i '/CFLAGS += -DOCR_RUNTIME_PROFILER -DPROFILER_KHZ=3400000/c\CFLAGS += -DOCR_RUNTIME_PROFILER -DPROFILER_KHZ=3400000' ~/ocr/ocr/build/common.mk"
    fi
    echo $MOD_CMD >> ${jfile}.sh
}

function modifyRsbenchMakefile()
{
    # uncomment and set CHUNK_SIZE to 1 instead of 1000 for RSBench only
    if [ $IS_RSBENCH -eq 1 ]; then
        echo "echo '===============================================' " >> ${jfile}.sh
        echo "echo ' Update RSBench Makefile.x86-base              ' " >> ${jfile}.sh
        echo "echo '===============================================' " >> ${jfile}.sh
        MOD_CMD="sed -i '/CFLAGS += -DSCHEDULER_TYPE=1 -DCHUNK_SIZE=1/c\CFLAGS += -DSCHEDULER_TYPE=1 -DCHUNK_SIZE=1' Makefile.x86-base"
        echo $MOD_CMD >> ${jfile}.sh
    fi
}

function addScript()
{
     if [ $IS_RSBENCH -eq 1 ]; then
        modifyRsbenchMakefile
     fi

     if [ $RUNTIME_CFG -eq 1 ]; then
         for rn in $(seq $TOTAL_RUN); do

	    echo "echo '===============================================' " >> ${jfile}.sh
	    echo "echo ' Run-time test: ${rn}                          ' " >> ${jfile}.sh
	    echo "echo '===============================================' " >> ${jfile}.sh
            jobHeader="runtime_${rn}"
            winstall="install_$jobHeader"
#	    mkdir -p ./${winstall}/tg/logs

            CLEAN_CMD="WORKLOAD_INSTALL_ROOT=./${winstall} make -f Makefile.${TARGET} clean uninstall "
            echo $CLEAN_CMD >> ${jfile}.sh

            CMD_OPT="CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./${winstall}"
	    if [ ! -z "$WORKLOAD" ]; then
		CMD_OPT="${CMD_OPT} WORKLOAD_ARGS='${WORKLOAD}'"
	    fi
#	    if [ ! -z "$CFGFILE" ]; then
#		CMD_OPT="${CMD_OPT} TG_CONFIG_TEMPLATE_CFG=config_msgStats.cfg"
#	    fi

            RUN_CMD="${CMD_OPT} make -f Makefile.${TARGET} run &> ${winstall}.out"
            echo $RUN_CMD >> ${jfile}.sh
        done
   fi
   
    if [ $PROFILE_CFG -eq 1 ]; then
        enableProfile 1

        for rn in $(seq $TOTAL_RUN); do

	    echo "echo '===============================================' " >> ${jfile}.sh
	    echo "echo ' Running profile: $rn	                       ' " >> ${jfile}.sh
	    echo "echo '===============================================' " >> ${jfile}.sh
	    jobHeader="profile_$rn"
            winstall="install_$jobHeader"
            resultfn="profile_result_$rn"

#	    mkdir -p ./${winstall}/tg/logs
            CLEAN_CMD="WORKLOAD_INSTALL_ROOT=./${winstall} make -f Makefile.${TARGET} clean uninstall "
            echo $CLEAN_CMD >> ${jfile}.sh

	    CMD_OPT="CONFIG_NUM_THREADS=64 WORKLOAD_INSTALL_ROOT=./${winstall}"
	    if [ ! -z "$WORKLOAD" ]; then
		CMD_OPT="${CMD_OPT} WORKLOAD_ARGS='${WORKLOAD}'"
	    fi
#	    if [ ! -z "$CFGFILE" ]; then
#		CMD_OPT="${CMD_OPT} TG_CONFIG_TEMPLATE_CFG=config_energy.cfg"
#	    fi

            RUN_CMD="${CMD_OPT} make -f Makefile.${TARGET} run &> ${winstall}.out"
            echo $RUN_CMD >> ${jfile}.sh

	    CDIR=$(pwd);
	    CD_CMD="cd ./${winstall}/${TARGET}/"
	    echo $CD_CMD >>  ${jfile}_postProfile.sh
	    POST_CMD="python ~/ocr/ocr/scripts/Profiler/analyzeProfile.py -t '*' >> ${resultfn}"
            echo $POST_CMD >> ${jfile}_postProfile.sh
            CD_CMD="cd ${CDIR}"
            echo $CD_CMD >> ${jfile}_postProfile.sh
        done
        enableProfile 0
    fi
}


###########################################################################
##  Script starts here...
###########################################################################

    jfile=jobScriptRtProfile
    rm ${jfile}.sh
    rm run_commands
    rm ${jfile}_postProfile.sh

    echo "#!/bin/bash" >> ${jfile}.sh
    echo >> ${jfile}.sh
    echo "#!/bin/bash" >> ${jfile}_postProfile.sh
    echo >> ${jfile}_postProfile.sh
    
    addScript

    chmod +x ${jfile}.sh
    chmod +x ${jfile}_postProfile.sh

    echo "./${jfile}.sh &> ${jfile}.out &" >> run_commands

    echo "echo '===============================================' " >> ${jfile}.sh
    echo "echo ' job completed.                                '"  >> ${jfile}.sh 
    echo "echo '===============================================' " >> ${jfile}.sh
