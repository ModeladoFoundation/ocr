#!/bin/bash

cd ./install_profile_1/x86-phi/
python ~/ocr/ocr/scripts/Profiler/analyzeProfile.py -t '*' >> profile_result_1
cd /home/dobrien/apps/apps/RSBench/refactored/ocr/intel-sharedDB
cd ./install_profile_2/x86-phi/
python ~/ocr/ocr/scripts/Profiler/analyzeProfile.py -t '*' >> profile_result_2
cd /home/dobrien/apps/apps/RSBench/refactored/ocr/intel-sharedDB
cd ./install_profile_3/x86-phi/
python ~/ocr/ocr/scripts/Profiler/analyzeProfile.py -t '*' >> profile_result_3
cd /home/dobrien/apps/apps/RSBench/refactored/ocr/intel-sharedDB
cd ./install_profile_4/x86-phi/
python ~/ocr/ocr/scripts/Profiler/analyzeProfile.py -t '*' >> profile_result_4
cd /home/dobrien/apps/apps/RSBench/refactored/ocr/intel-sharedDB
cd ./install_profile_5/x86-phi/
python ~/ocr/ocr/scripts/Profiler/analyzeProfile.py -t '*' >> profile_result_5
cd /home/dobrien/apps/apps/RSBench/refactored/ocr/intel-sharedDB
cd ./install_profile_6/x86-phi/
python ~/ocr/ocr/scripts/Profiler/analyzeProfile.py -t '*' >> profile_result_6
cd /home/dobrien/apps/apps/RSBench/refactored/ocr/intel-sharedDB
cd ./install_profile_7/x86-phi/
python ~/ocr/ocr/scripts/Profiler/analyzeProfile.py -t '*' >> profile_result_7
cd /home/dobrien/apps/apps/RSBench/refactored/ocr/intel-sharedDB
cd ./install_profile_8/x86-phi/
python ~/ocr/ocr/scripts/Profiler/analyzeProfile.py -t '*' >> profile_result_8
cd /home/dobrien/apps/apps/RSBench/refactored/ocr/intel-sharedDB
cd ./install_profile_9/x86-phi/
python ~/ocr/ocr/scripts/Profiler/analyzeProfile.py -t '*' >> profile_result_9
cd /home/dobrien/apps/apps/RSBench/refactored/ocr/intel-sharedDB
cd ./install_profile_10/x86-phi/
python ~/ocr/ocr/scripts/Profiler/analyzeProfile.py -t '*' >> profile_result_10
cd /home/dobrien/apps/apps/RSBench/refactored/ocr/intel-sharedDB
