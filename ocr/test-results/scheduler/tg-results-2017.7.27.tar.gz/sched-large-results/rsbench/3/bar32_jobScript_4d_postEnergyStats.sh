#!/bin/bash

python /lustre/home/srobinson/testing_repos/bar32/apps/apps/../../ocr/ocr/scripts/tgStats/tgStats.py ./install_c3_energy_pd_1_xe_0_ce_0_sq_1_4b/tg/logs
mv results/ ./install_c3_energy_pd_1_xe_0_ce_0_sq_1_4b/tg/
python /lustre/home/srobinson/testing_repos/bar32/apps/apps/../../ocr/ocr/scripts/tgStats/tgStats.py ./install_cs3_energy_pd_1_xe_0_ce_0_sq_1_4b/tg/logs
mv results/ ./install_cs3_energy_pd_1_xe_0_ce_0_sq_1_4b/tg/
