#!/bin/bash

python /home/srobinson/testing_repos/bar31/apps/apps/../../ocr/ocr/scripts/tgStats/tgStats.py ./install_c2_energy_pd_1_xe_1_ce_1_sq_0_4b/tg/logs
mv results/ ./install_c2_energy_pd_1_xe_1_ce_1_sq_0_4b/tg/
python /home/srobinson/testing_repos/bar31/apps/apps/../../ocr/ocr/scripts/tgStats/tgStats.py ./install_cs2_energy_pd_1_xe_1_ce_1_sq_0_4b/tg/logs
mv results/ ./install_cs2_energy_pd_1_xe_1_ce_1_sq_0_4b/tg/
