#!/bin/bash

/home/srobinson/testing_repos/bar30/apps/apps/../../ocr/ocr/scripts/MsgStats/msgstats.sh ./install_c1_msgstats_pd_1_xe_0_ce_0_sq_0_4b/tg/logs msgstats.csv
mv msgstats.csv ./install_c1_msgstats_pd_1_xe_0_ce_0_sq_0_4b/tg/
/home/srobinson/testing_repos/bar30/apps/apps/../../ocr/ocr/scripts/MsgStats/msgstats.sh ./install_cs1_msgstats_pd_1_xe_0_ce_0_sq_0_4b/tg/logs msgstats.csv
mv msgstats.csv ./install_cs1_msgstats_pd_1_xe_0_ce_0_sq_0_4b/tg/
