#!/bin/bash

/home/srobinson/testing_repos/bar28/apps/apps/../../ocr/ocr/scripts/MsgStats/msgstats.sh ./install_c2_msgstats_pd_1_xe_1_ce_1_sq_0_4b/tg/logs msgstats.csv
mv msgstats.csv ./install_c2_msgstats_pd_1_xe_1_ce_1_sq_0_4b/tg/
/home/srobinson/testing_repos/bar28/apps/apps/../../ocr/ocr/scripts/MsgStats/msgstats.sh ./install_cs2_msgstats_pd_1_xe_1_ce_1_sq_0_4b/tg/logs msgstats.csv
mv msgstats.csv ./install_cs2_msgstats_pd_1_xe_1_ce_1_sq_0_4b/tg/
