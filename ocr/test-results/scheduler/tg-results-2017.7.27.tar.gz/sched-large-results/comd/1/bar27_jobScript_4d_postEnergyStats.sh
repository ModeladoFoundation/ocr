#!/bin/bash

python /home/srobinson/testing_repos/bar27/apps/apps/../../ocr/ocr/scripts/tgStats/tgStats.py ./install_c1_energy_pd_1_xe_0_ce_0_sq_0_4b/tg/logs
mv results/ ./install_c1_energy_pd_1_xe_0_ce_0_sq_0_4b/tg/
python /home/srobinson/testing_repos/bar27/apps/apps/../../ocr/ocr/scripts/tgStats/tgStats.py ./install_cs1_energy_pd_1_xe_0_ce_0_sq_0_4b/tg/logs
mv results/ ./install_cs1_energy_pd_1_xe_0_ce_0_sq_0_4b/tg/
