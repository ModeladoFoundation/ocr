#!/bin/bash

echo '==========================================================' 
echo ' Setting configuration: Case 3 in bar29_jobScript_4d.sh       ' 
echo ' -OCR_SHARED_XE_POLICY_DOMMAIN: 1                 ' 
echo ' -OCR_ENABLE_XE_L2_ALLOC: 1                       ' 
echo ' -OCR_ENABLE_XE_GET_MULTI_WORK: 0                 ' 
echo ' -OCR_ENABLE_CE_GET_MULTI_WORK: 0                 ' 
echo ' -OCR_ENABLE_SCHEDULER_SPAWN_QUEUE: 1             ' 
echo ' -LOGGING_PATCH: /lustre/home/srobinson/testing_repos/sched-debug.patch         ' 
echo '==========================================================' 
sed -i '/#define ENABLE_NEWLIB_SCAFFOLD_TG/c\#define ENABLE_NEWLIB_SCAFFOLD_TG' /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/tg-xe/ocr-config.h
sed -i '/CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN/c\CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN' /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_XE_L2_ALLOC/c\CFLAGS += -DOCR_ENABLE_XE_L2_ALLOC' /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK/c\# CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK' /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK/c\# CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK' /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_SCHEDULER_SPAWN_QUEUE/c\CFLAGS += -DOCR_ENABLE_SCHEDULER_SPAWN_QUEUE' /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DENABLE_SPAWNING_HINT/c\CFLAGS += -DENABLE_SPAWNING_HINT' Makefile.tg
echo 'Patching for logging with /lustre/home/srobinson/testing_repos/sched-debug.patch                 ' 
{ patch --dry-run -p1 -R -d /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr < /lustre/home/srobinson/testing_repos/sched-debug.patch &>/dev/null && echo 'already patched';} || \
patch -p1 -d /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr < /lustre/home/srobinson/testing_repos/sched-debug.patch
date
echo '===============================================' 
echo ' Running MsgStats test	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_c3_msgstats_pd_1_xe_0_ce_0_sq_1_4b make -f Makefile.tg clean uninstall
WORKLOAD_INSTALL_ROOT=./install_c3_msgstats_pd_1_xe_0_ce_0_sq_1_4b WORKLOAD_ARGS='-x 32 -y 32 -z 16 -i 4 -j 4 -k 2 -N 4 -n 4' TG_CONFIG_TEMPLATE_CFG=config_msgStats.cfg make -f Makefile.tg run
cp /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/tg-xe/ocr-config.h ./install_c3_msgstats_pd_1_xe_0_ce_0_sq_1_4b/tg/ocr-config.h.sav
cp /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/common.mk ./install_c3_msgstats_pd_1_xe_0_ce_0_sq_1_4b/tg/common.mk.sav
cp Makefile.tg ./install_c3_msgstats_pd_1_xe_0_ce_0_sq_1_4b/tg/Makefile.tg.sav
echo 'Unpatching logging from /lustre/home/srobinson/testing_repos/sched-debug.patch                 ' 
{ patch --dry-run -p1 -d /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr < /lustre/home/srobinson/testing_repos/sched-debug.patch &>/dev/null && echo 'already unpatched';} || \
patch -R -p1 -d /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr < /lustre/home/srobinson/testing_repos/sched-debug.patch
date
echo '===============================================' 
echo ' Running Energy test	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_c3_energy_pd_1_xe_0_ce_0_sq_1_4b make -f Makefile.tg clean uninstall
ENERGY=yes WORKLOAD_INSTALL_ROOT=./install_c3_energy_pd_1_xe_0_ce_0_sq_1_4b WORKLOAD_ARGS='-x 32 -y 32 -z 16 -i 4 -j 4 -k 2 -N 4 -n 4' TG_CONFIG_TEMPLATE_CFG=config_energy.cfg make -f Makefile.tg run
cp /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/tg-xe/ocr-config.h ./install_c3_energy_pd_1_xe_0_ce_0_sq_1_4b/tg/ocr-config.h.sav
cp /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/common.mk ./install_c3_energy_pd_1_xe_0_ce_0_sq_1_4b/tg/common.mk.sav
cp Makefile.tg ./install_c3_energy_pd_1_xe_0_ce_0_sq_1_4b/tg/Makefile.tg.sav
echo '==========================================================' 
echo ' Setting configuration: Case s3 in bar29_jobScript_4d.sh       ' 
echo ' -OCR_SHARED_XE_POLICY_DOMMAIN: 1                 ' 
echo ' -OCR_ENABLE_XE_L2_ALLOC: 1                       ' 
echo ' -OCR_ENABLE_XE_GET_MULTI_WORK: 0                 ' 
echo ' -OCR_ENABLE_CE_GET_MULTI_WORK: 0                 ' 
echo ' -OCR_ENABLE_SCHEDULER_SPAWN_QUEUE: 1             ' 
echo ' -LOGGING_PATCH: /lustre/home/srobinson/testing_repos/sched-debug.patch         ' 
echo '==========================================================' 
sed -i '/#define ENABLE_NEWLIB_SCAFFOLD_TG/c\#define ENABLE_NEWLIB_SCAFFOLD_TG' /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/tg-xe/ocr-config.h
sed -i '/CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN/c\CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN' /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_XE_L2_ALLOC/c\CFLAGS += -DOCR_ENABLE_XE_L2_ALLOC' /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK/c\# CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK' /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK/c\# CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK' /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_SCHEDULER_SPAWN_QUEUE/c\CFLAGS += -DOCR_ENABLE_SCHEDULER_SPAWN_QUEUE' /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DENABLE_SPAWNING_HINT/c\CFLAGS += -DENABLE_SPAWNING_HINT' Makefile.tg
echo 'Patching for logging with /lustre/home/srobinson/testing_repos/sched-debug.patch                 ' 
{ patch --dry-run -p1 -R -d /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr < /lustre/home/srobinson/testing_repos/sched-debug.patch &>/dev/null && echo 'already patched';} || \
patch -p1 -d /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr < /lustre/home/srobinson/testing_repos/sched-debug.patch
date
echo '===============================================' 
echo ' Running MsgStats test	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_cs3_msgstats_pd_1_xe_0_ce_0_sq_1_4b make -f Makefile.tg clean uninstall
WORKLOAD_INSTALL_ROOT=./install_cs3_msgstats_pd_1_xe_0_ce_0_sq_1_4b WORKLOAD_ARGS='-x 32 -y 32 -z 16 -i 4 -j 4 -k 2 -N 1 -n 1' TG_CONFIG_TEMPLATE_CFG=config_msgStats.cfg make -f Makefile.tg run
cp /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/tg-xe/ocr-config.h ./install_cs3_msgstats_pd_1_xe_0_ce_0_sq_1_4b/tg/ocr-config.h.sav
cp /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/common.mk ./install_cs3_msgstats_pd_1_xe_0_ce_0_sq_1_4b/tg/common.mk.sav
cp Makefile.tg ./install_cs3_msgstats_pd_1_xe_0_ce_0_sq_1_4b/tg/Makefile.tg.sav
echo 'Unpatching logging from /lustre/home/srobinson/testing_repos/sched-debug.patch                 ' 
{ patch --dry-run -p1 -d /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr < /lustre/home/srobinson/testing_repos/sched-debug.patch &>/dev/null && echo 'already unpatched';} || \
patch -R -p1 -d /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr < /lustre/home/srobinson/testing_repos/sched-debug.patch
date
echo '===============================================' 
echo ' Running Energy test	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_cs3_energy_pd_1_xe_0_ce_0_sq_1_4b make -f Makefile.tg clean uninstall
ENERGY=yes WORKLOAD_INSTALL_ROOT=./install_cs3_energy_pd_1_xe_0_ce_0_sq_1_4b WORKLOAD_ARGS='-x 32 -y 32 -z 16 -i 4 -j 4 -k 2 -N 1 -n 1' TG_CONFIG_TEMPLATE_CFG=config_energy.cfg make -f Makefile.tg run
cp /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/tg-xe/ocr-config.h ./install_cs3_energy_pd_1_xe_0_ce_0_sq_1_4b/tg/ocr-config.h.sav
cp /lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/build/common.mk ./install_cs3_energy_pd_1_xe_0_ce_0_sq_1_4b/tg/common.mk.sav
cp Makefile.tg ./install_cs3_energy_pd_1_xe_0_ce_0_sq_1_4b/tg/Makefile.tg.sav
