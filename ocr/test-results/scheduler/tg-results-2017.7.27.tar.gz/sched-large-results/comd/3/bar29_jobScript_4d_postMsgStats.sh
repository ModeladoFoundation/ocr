#!/bin/bash

/lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/scripts/MsgStats/msgstats.sh ./install_c3_msgstats_pd_1_xe_0_ce_0_sq_1_4b/tg/logs msgstats.csv
mv msgstats.csv ./install_c3_msgstats_pd_1_xe_0_ce_0_sq_1_4b/tg/
/lustre/home/srobinson/testing_repos/bar29/apps/apps/../../ocr/ocr/scripts/MsgStats/msgstats.sh ./install_cs3_msgstats_pd_1_xe_0_ce_0_sq_1_4b/tg/logs msgstats.csv
mv msgstats.csv ./install_cs3_msgstats_pd_1_xe_0_ce_0_sq_1_4b/tg/
