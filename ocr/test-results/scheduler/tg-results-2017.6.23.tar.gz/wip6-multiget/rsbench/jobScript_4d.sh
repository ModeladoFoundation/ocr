#!/bin/bash

#echo '==========================================================' 
#echo ' Setting configuration: Case 1 in jobScript_4d.sh       ' 
#echo ' -OCR_SHARED_XE_POLICY_DOMMAIN: 0                 ' 
#echo ' -OCR_ENABLE_XE_GET_MULTI_WORK: 0                 ' 
#echo ' -OCR_ENABLE_CE_GET_MULTI_WORK: 0                 ' 
#echo '==========================================================' 
#sed -i '/CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN/c\# CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN' ~/ocr/ocr/build/common.mk
#sed -i '/CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK/c\# CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK' ~/ocr/ocr/build/common.mk
#sed -i '/CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK/c\# CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK' ~/ocr/ocr/build/common.mk
#date
#echo '===============================================' 
#echo ' Running MsgStats test	                       ' 
#echo '===============================================' 
#WORKLOAD_INSTALL_ROOT=./install_c1_msgstats_pd_0_xe_0_ce_0_4d make -f Makefile.tg clean uninstall
#WORKLOAD_INSTALL_ROOT=./install_c1_msgstats_pd_0_xe_0_ce_0_4d WORKLOAD_ARGS='-d -s small -t 32 -l 12801' TG_CONFIG_TEMPLATE_CFG=config_msgStats.cfg make -f Makefile.tg run
#date
#echo '===============================================' 
#echo ' Running Energy test	                       ' 
#echo '===============================================' 
#WORKLOAD_INSTALL_ROOT=./install_c1_energy_pd_0_xe_0_ce_0_4d make -f Makefile.tg clean uninstall
#ENERGY=yes WORKLOAD_INSTALL_ROOT=./install_c1_energy_pd_0_xe_0_ce_0_4d WORKLOAD_ARGS='-d -s small -t 32 -l 12801' TG_CONFIG_TEMPLATE_CFG=config_energy.cfg make -f Makefile.tg run
#echo '==========================================================' 
#echo ' Setting configuration: Case 2 in jobScript_4d.sh       ' 
#echo ' -OCR_SHARED_XE_POLICY_DOMMAIN: 0                 ' 
#echo ' -OCR_ENABLE_XE_GET_MULTI_WORK: 0                 ' 
#echo ' -OCR_ENABLE_CE_GET_MULTI_WORK: 1                 ' 
#echo '==========================================================' 
#sed -i '/CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN/c\# CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN' ~/ocr/ocr/build/common.mk
#sed -i '/CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK/c\# CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK' ~/ocr/ocr/build/common.mk
#sed -i '/CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK/c\CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK' ~/ocr/ocr/build/common.mk
#date
#echo '===============================================' 
#echo ' Running MsgStats test	                       ' 
#echo '===============================================' 
#WORKLOAD_INSTALL_ROOT=./install_c2_msgstats_pd_0_xe_0_ce_1_4d make -f Makefile.tg clean uninstall
#WORKLOAD_INSTALL_ROOT=./install_c2_msgstats_pd_0_xe_0_ce_1_4d WORKLOAD_ARGS='-d -s small -t 32 -l 12801' TG_CONFIG_TEMPLATE_CFG=config_msgStats.cfg make -f Makefile.tg run
#date
#echo '===============================================' 
#echo ' Running Energy test	                       ' 
#echo '===============================================' 
#WORKLOAD_INSTALL_ROOT=./install_c2_energy_pd_0_xe_0_ce_1_4d make -f Makefile.tg clean uninstall
#ENERGY=yes WORKLOAD_INSTALL_ROOT=./install_c2_energy_pd_0_xe_0_ce_1_4d WORKLOAD_ARGS='-d -s small -t 32 -l 12801' TG_CONFIG_TEMPLATE_CFG=config_energy.cfg make -f Makefile.tg run
#echo '==========================================================' 
#echo ' Setting configuration: Case 3 in jobScript_4d.sh       ' 
#echo ' -OCR_SHARED_XE_POLICY_DOMMAIN: 1                 ' 
#echo ' -OCR_ENABLE_XE_GET_MULTI_WORK: 0                 ' 
#echo ' -OCR_ENABLE_CE_GET_MULTI_WORK: 0                 ' 
#echo '==========================================================' 
#sed -i '/CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN/c\CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN' ~/ocr/ocr/build/common.mk
#sed -i '/CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK/c\# CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK' ~/ocr/ocr/build/common.mk
#sed -i '/CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK/c\# CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK' ~/ocr/ocr/build/common.mk
#date
#echo '===============================================' 
#echo ' Running MsgStats test	                       ' 
#echo '===============================================' 
#WORKLOAD_INSTALL_ROOT=./install_c3_msgstats_pd_1_xe_0_ce_0_4d make -f Makefile.tg clean uninstall
#WORKLOAD_INSTALL_ROOT=./install_c3_msgstats_pd_1_xe_0_ce_0_4d WORKLOAD_ARGS='-d -s small -t 32 -l 12801' TG_CONFIG_TEMPLATE_CFG=config_msgStats.cfg make -f Makefile.tg run
#date
#echo '===============================================' 
#echo ' Running Energy test	                       ' 
#echo '===============================================' 
#WORKLOAD_INSTALL_ROOT=./install_c3_energy_pd_1_xe_0_ce_0_4d make -f Makefile.tg clean uninstall
#ENERGY=yes WORKLOAD_INSTALL_ROOT=./install_c3_energy_pd_1_xe_0_ce_0_4d WORKLOAD_ARGS='-d -s small -t 32 -l 12801' TG_CONFIG_TEMPLATE_CFG=config_energy.cfg make -f Makefile.tg run
echo '==========================================================' 
echo ' Setting configuration: Case 4 in jobScript_4d.sh       ' 
echo ' -OCR_SHARED_XE_POLICY_DOMMAIN: 1                 ' 
echo ' -OCR_ENABLE_XE_GET_MULTI_WORK: 1                 ' 
echo ' -OCR_ENABLE_CE_GET_MULTI_WORK: 0                 ' 
echo '==========================================================' 
sed -i '/CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN/c\CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK/c\CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK/c\# CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK' ~/ocr/ocr/build/common.mk
date
echo '===============================================' 
echo ' Running MsgStats test	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_c4_msgstats_pd_1_xe_1_ce_0_4d make -f Makefile.tg clean uninstall
WORKLOAD_INSTALL_ROOT=./install_c4_msgstats_pd_1_xe_1_ce_0_4d WORKLOAD_ARGS='-d -s small -t 32 -l 12801' TG_CONFIG_TEMPLATE_CFG=config_msgStats.cfg make -f Makefile.tg run
date
echo '===============================================' 
echo ' Running Energy test	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_c4_energy_pd_1_xe_1_ce_0_4d make -f Makefile.tg clean uninstall
ENERGY=yes WORKLOAD_INSTALL_ROOT=./install_c4_energy_pd_1_xe_1_ce_0_4d WORKLOAD_ARGS='-d -s small -t 32 -l 12801' TG_CONFIG_TEMPLATE_CFG=config_energy.cfg make -f Makefile.tg run
echo '==========================================================' 
echo ' Setting configuration: Case 5 in jobScript_4d.sh       ' 
echo ' -OCR_SHARED_XE_POLICY_DOMMAIN: 1                 ' 
echo ' -OCR_ENABLE_XE_GET_MULTI_WORK: 1                 ' 
echo ' -OCR_ENABLE_CE_GET_MULTI_WORK: 1                 ' 
echo '==========================================================' 
sed -i '/CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN/c\CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK/c\CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK/c\CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK' ~/ocr/ocr/build/common.mk
date
echo '===============================================' 
echo ' Running MsgStats test	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_c5_msgstats_pd_1_xe_1_ce_1_4d make -f Makefile.tg clean uninstall
WORKLOAD_INSTALL_ROOT=./install_c5_msgstats_pd_1_xe_1_ce_1_4d WORKLOAD_ARGS='-d -s small -t 32 -l 12801' TG_CONFIG_TEMPLATE_CFG=config_msgStats.cfg make -f Makefile.tg run
date
echo '===============================================' 
echo ' Running Energy test	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_c5_energy_pd_1_xe_1_ce_1_4d make -f Makefile.tg clean uninstall
ENERGY=yes WORKLOAD_INSTALL_ROOT=./install_c5_energy_pd_1_xe_1_ce_1_4d WORKLOAD_ARGS='-d -s small -t 32 -l 12801' TG_CONFIG_TEMPLATE_CFG=config_energy.cfg make -f Makefile.tg run
