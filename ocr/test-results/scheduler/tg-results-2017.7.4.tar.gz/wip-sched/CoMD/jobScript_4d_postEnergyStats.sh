#!/bin/bash

python ~/ocr/ocr/scripts/tgStats/tgStats.py ./install_c1_energy_pd_1_xe_0_ce_0_sq_0_4b/tg/logs
mv results/ ./install_c1_energy_pd_1_xe_0_ce_0_sq_0_4b/tg/
python ~/ocr/ocr/scripts/tgStats/tgStats.py ./install_c2_energy_pd_1_xe_1_ce_1_sq_0_4b/tg/logs
mv results/ ./install_c2_energy_pd_1_xe_1_ce_1_sq_0_4b/tg/
python ~/ocr/ocr/scripts/tgStats/tgStats.py ./install_c3_energy_pd_1_xe_0_ce_0_sq_1_4b/tg/logs
mv results/ ./install_c3_energy_pd_1_xe_0_ce_0_sq_1_4b/tg/
