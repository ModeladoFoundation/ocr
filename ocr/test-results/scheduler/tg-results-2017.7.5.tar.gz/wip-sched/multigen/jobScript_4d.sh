#!/bin/bash

echo '==========================================================' 
echo ' Setting configuration: Case 1 in jobScript_4d.sh       ' 
echo ' -OCR_SHARED_XE_POLICY_DOMMAIN: 1                 ' 
echo ' -OCR_ENABLE_XE_L2_ALLOC: 1                       ' 
echo ' -OCR_ENABLE_XE_GET_MULTI_WORK: 0                 ' 
echo ' -OCR_ENABLE_CE_GET_MULTI_WORK: 0                 ' 
echo ' -ENABLE_SCHEDULER_OBJECT_SPAWN_QUEUE: 0          ' 
echo '==========================================================' 
sed -i '/#define ENABLE_NEWLIB_SCAFFOLD_TG/c\/\/#define ENABLE_NEWLIB_SCAFFOLD_TG' ~/ocr/ocr/build/tg-xe/ocr-config.h
sed -i '/CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN/c\CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_XE_L2_ALLOC/c\CFLAGS += -DOCR_ENABLE_XE_L2_ALLOC' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK/c\# CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK/c\# CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DENABLE_SCHEDULER_OBJECT_SPAWN_QUEUE/c\# CFLAGS += -DENABLE_SCHEDULER_OBJECT_SPAWN_QUEUE' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DENABLE_SPAWNING_HINT/c\#CFLAGS += -DENABLE_SPAWNING_HINT' Makefile.tg
date
echo '===============================================' 
echo ' Running MsgStats test	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_c1_msgstats_pd_1_xe_0_ce_0_sq_0_4b make -f Makefile.tg clean uninstall
WORKLOAD_INSTALL_ROOT=./install_c1_msgstats_pd_1_xe_0_ce_0_sq_0_4b TG_CONFIG_TEMPLATE_CFG=config_msgStats.cfg make -f Makefile.tg run
cp ~/ocr/ocr/build/tg-xe/ocr-config.h ./install_c1_msgstats_pd_1_xe_0_ce_0_sq_0_4b/tg/ocr-config.h.sav
cp ~/ocr/ocr/build/common.mk ./install_c1_msgstats_pd_1_xe_0_ce_0_sq_0_4b/tg/common.mk.sav
cp Makefile.tg ./install_c1_msgstats_pd_1_xe_0_ce_0_sq_0_4b/tg/Makefile.tg.sav
date
echo '===============================================' 
echo ' Running Energy test	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_c1_energy_pd_1_xe_0_ce_0_sq_0_4b make -f Makefile.tg clean uninstall
ENERGY=yes WORKLOAD_INSTALL_ROOT=./install_c1_energy_pd_1_xe_0_ce_0_sq_0_4b TG_CONFIG_TEMPLATE_CFG=config_energy.cfg make -f Makefile.tg run
cp ~/ocr/ocr/build/tg-xe/ocr-config.h ./install_c1_energy_pd_1_xe_0_ce_0_sq_0_4b/tg/ocr-config.h.sav
cp ~/ocr/ocr/build/common.mk ./install_c1_energy_pd_1_xe_0_ce_0_sq_0_4b/tg/common.mk.sav
cp Makefile.tg ./install_c1_energy_pd_1_xe_0_ce_0_sq_0_4b/tg/Makefile.tg.sav
echo '==========================================================' 
echo ' Setting configuration: Case 2 in jobScript_4d.sh       ' 
echo ' -OCR_SHARED_XE_POLICY_DOMMAIN: 1                 ' 
echo ' -OCR_ENABLE_XE_L2_ALLOC: 1                       ' 
echo ' -OCR_ENABLE_XE_GET_MULTI_WORK: 1                 ' 
echo ' -OCR_ENABLE_CE_GET_MULTI_WORK: 1                 ' 
echo ' -ENABLE_SCHEDULER_OBJECT_SPAWN_QUEUE: 0          ' 
echo '==========================================================' 
sed -i '/#define ENABLE_NEWLIB_SCAFFOLD_TG/c\/\/#define ENABLE_NEWLIB_SCAFFOLD_TG' ~/ocr/ocr/build/tg-xe/ocr-config.h
sed -i '/CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN/c\CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_XE_L2_ALLOC/c\CFLAGS += -DOCR_ENABLE_XE_L2_ALLOC' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK/c\CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK/c\CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DENABLE_SCHEDULER_OBJECT_SPAWN_QUEUE/c\# CFLAGS += -DENABLE_SCHEDULER_OBJECT_SPAWN_QUEUE' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DENABLE_SPAWNING_HINT/c\#CFLAGS += -DENABLE_SPAWNING_HINT' Makefile.tg
date
echo '===============================================' 
echo ' Running MsgStats test	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_c2_msgstats_pd_1_xe_1_ce_1_sq_0_4b make -f Makefile.tg clean uninstall
WORKLOAD_INSTALL_ROOT=./install_c2_msgstats_pd_1_xe_1_ce_1_sq_0_4b TG_CONFIG_TEMPLATE_CFG=config_msgStats.cfg make -f Makefile.tg run
cp ~/ocr/ocr/build/tg-xe/ocr-config.h ./install_c2_msgstats_pd_1_xe_1_ce_1_sq_0_4b/tg/ocr-config.h.sav
cp ~/ocr/ocr/build/common.mk ./install_c2_msgstats_pd_1_xe_1_ce_1_sq_0_4b/tg/common.mk.sav
cp Makefile.tg ./install_c2_msgstats_pd_1_xe_1_ce_1_sq_0_4b/tg/Makefile.tg.sav
date
echo '===============================================' 
echo ' Running Energy test	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_c2_energy_pd_1_xe_1_ce_1_sq_0_4b make -f Makefile.tg clean uninstall
ENERGY=yes WORKLOAD_INSTALL_ROOT=./install_c2_energy_pd_1_xe_1_ce_1_sq_0_4b TG_CONFIG_TEMPLATE_CFG=config_energy.cfg make -f Makefile.tg run
cp ~/ocr/ocr/build/tg-xe/ocr-config.h ./install_c2_energy_pd_1_xe_1_ce_1_sq_0_4b/tg/ocr-config.h.sav
cp ~/ocr/ocr/build/common.mk ./install_c2_energy_pd_1_xe_1_ce_1_sq_0_4b/tg/common.mk.sav
cp Makefile.tg ./install_c2_energy_pd_1_xe_1_ce_1_sq_0_4b/tg/Makefile.tg.sav
echo '==========================================================' 
echo ' Setting configuration: Case 3 in jobScript_4d.sh       ' 
echo ' -OCR_SHARED_XE_POLICY_DOMMAIN: 1                 ' 
echo ' -OCR_ENABLE_XE_L2_ALLOC: 1                       ' 
echo ' -OCR_ENABLE_XE_GET_MULTI_WORK: 0                 ' 
echo ' -OCR_ENABLE_CE_GET_MULTI_WORK: 0                 ' 
echo ' -ENABLE_SCHEDULER_OBJECT_SPAWN_QUEUE: 1          ' 
echo '==========================================================' 
sed -i '/#define ENABLE_NEWLIB_SCAFFOLD_TG/c\/\/#define ENABLE_NEWLIB_SCAFFOLD_TG' ~/ocr/ocr/build/tg-xe/ocr-config.h
sed -i '/CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN/c\CFLAGS += -DOCR_SHARED_XE_POLICY_DOMAIN' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_XE_L2_ALLOC/c\CFLAGS += -DOCR_ENABLE_XE_L2_ALLOC' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK/c\# CFLAGS += -DOCR_ENABLE_XE_GET_MULTI_WORK' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK/c\# CFLAGS += -DOCR_ENABLE_CE_GET_MULTI_WORK' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DENABLE_SCHEDULER_OBJECT_SPAWN_QUEUE/c\CFLAGS += -DENABLE_SCHEDULER_OBJECT_SPAWN_QUEUE' ~/ocr/ocr/build/common.mk
sed -i '/CFLAGS += -DENABLE_SPAWNING_HINT/c\CFLAGS += -DENABLE_SPAWNING_HINT' Makefile.tg
date
echo '===============================================' 
echo ' Running MsgStats test	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_c3_msgstats_pd_1_xe_0_ce_0_sq_1_4b make -f Makefile.tg clean uninstall
WORKLOAD_INSTALL_ROOT=./install_c3_msgstats_pd_1_xe_0_ce_0_sq_1_4b TG_CONFIG_TEMPLATE_CFG=config_msgStats.cfg make -f Makefile.tg run
cp ~/ocr/ocr/build/tg-xe/ocr-config.h ./install_c3_msgstats_pd_1_xe_0_ce_0_sq_1_4b/tg/ocr-config.h.sav
cp ~/ocr/ocr/build/common.mk ./install_c3_msgstats_pd_1_xe_0_ce_0_sq_1_4b/tg/common.mk.sav
cp Makefile.tg ./install_c3_msgstats_pd_1_xe_0_ce_0_sq_1_4b/tg/Makefile.tg.sav
date
echo '===============================================' 
echo ' Running Energy test	                       ' 
echo '===============================================' 
WORKLOAD_INSTALL_ROOT=./install_c3_energy_pd_1_xe_0_ce_0_sq_1_4b make -f Makefile.tg clean uninstall
ENERGY=yes WORKLOAD_INSTALL_ROOT=./install_c3_energy_pd_1_xe_0_ce_0_sq_1_4b TG_CONFIG_TEMPLATE_CFG=config_energy.cfg make -f Makefile.tg run
cp ~/ocr/ocr/build/tg-xe/ocr-config.h ./install_c3_energy_pd_1_xe_0_ce_0_sq_1_4b/tg/ocr-config.h.sav
cp ~/ocr/ocr/build/common.mk ./install_c3_energy_pd_1_xe_0_ce_0_sq_1_4b/tg/common.mk.sav
cp Makefile.tg ./install_c3_energy_pd_1_xe_0_ce_0_sq_1_4b/tg/Makefile.tg.sav
