#!/bin/bash

if [[ $# < 1 ]]; then
  echo "Usage: $(basename $0) log_directory [out.csv]"
  exit 1
fi

out_filename=${2-out.csv}

for log in $1/*blk*.CE.[0-9][0-9]; do
  block=$(echo $log | sed 's/.*blk//' | cut -c-2)
  echo "block $block"
  cat $log
done | gawk -f commstats.awk > $out_filename
