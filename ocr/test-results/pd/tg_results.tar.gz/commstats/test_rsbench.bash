#!/bin/bash

if [[ $# < 1 ]]; then
  echo "Usage: $(basename $0) log_directory"
  exit 1
fi

if [ -d $1 ]
then
  echo "Directory already exisits"
  exit 1
fi

mkdir -p $1
echo "created directory $1"

cp ~/apps/apps/RSBench/refactored/ocr/intel-sharedDB/install/tg/logs/*blk*.CE.[0-9][0-9] $1/.
#cp /home/dobrien/bar3/apps/apps/RSBench/refactored/ocr/intel-sharedDB/install/tg/logs/*blk*.CE.[0-9][0-9] $1/.
echo "copied all block log files to directory $1"

echo "Total COMM-PLAT(MSG) in all block files: "
grep "COMM-PLAT(MSG)" $1/* | grep -c ^

echo "calling commstats.bash..."
./commstats.bash $1 $1/out.csv
